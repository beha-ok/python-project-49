from prompt import string


def engine_games(game):
    count = 0
    print("Welcome to the Brain Games!")
    what_name = string("May I have your name? ")
    print(f'{game.game_offer}')
    while count < 3:
        questions, result_questions = game.raund()
        print(f"Question: {questions}")
        answer = string(f"Your answer: ")
        if answer != result_questions:
            print(f"{answer} is wrong answer ;(. "
            f"/nCorrect answer was {result_questions}"
            f"Let's try again, Sam!")
        else:
            count += 1
            print(f'Correct!')
            break
    return print(f"Congratulations, {what_name}!")
    