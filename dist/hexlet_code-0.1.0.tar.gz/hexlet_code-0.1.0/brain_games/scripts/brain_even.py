#!/usr/bin/env python3
from brain_games.logic_game_even import user_game


def main():
    print("Welcome to the Brain Games!")
    user_game()


if __name__ == '__main__':
    main()
